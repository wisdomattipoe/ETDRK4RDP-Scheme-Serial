#!/bin/bash
gfortran -o uf1b umfpack.f90 umfpack_simple_1basic.f90 -lumfpack
ifort -o uf1b umfpack.f90 umfpack_simple_1basic.f90 -lumfpack
pgfortran -o uf1b umfpack.f90 umfpack_simple_1basic.f90 -lumfpack
g95 -o uf1b umfpack.f90 umfpack_simple_1basic.f90 -lumfpack
