%% Solution to 2D Brusselator Using Semi implicit BDF4 scheme 
% boundary conditions
% E.O Asante-Asamani
% 07/13/2023

function [runtime,u_soln] = Brusselator2D_SBDF4(dt,steps)
 clc; close all

% dt: time step
% steps: Number of nodes

%% Model Paramters and initial conditions
aparm = 1; bparm = 3.4;

% diffusion coefficient
epsln1 = 2.e-3; epsln2 = 2.e-3;

% create nodes
x = linspace(0,1,steps); 
h = x(2)-x(1);
y = x;
nnodes = steps^2;
nodes = zeros(nnodes,2);
j = 1;
for k = 1 : steps
        for i = 1:steps
               nodes(j,:) = [x(i) y(k)];
            j = j+1;
        end
end
nb = 2*nnodes; % becuase we are solving a system of 2 RDE

% discretize time interval
t = 0:dt:2; tlen = length(t);

% initial condition for u
u_old = 0.5 + nodes(:,2); 

% initial condition for v
v_old = 1 + 5*nodes(:,1); 

% Stacking nodes for evolution
w_old = zeros(nb,1);
w_old(1:2:nb-1) = u_old; w_old(2:2:nb) = v_old; 

%% Block matrix Assembly

C = zeros(2);
C(1,1) = (epsln1)/(12*h^2);
C(2,2) = (epsln2)/(12*h^2);
e = ones(steps,1); Id = speye(nb);I = eye(steps);
As = spdiags([-e 16*e -30*e 16*e -e], -2:2, steps, steps); % finite difference diffusion operator

% first and last row
As(1,2) =  32;
As(end,end-1) = 32;
As(1,3) = -2;
As(end,end-2) = -2;

% second and second to last row
As(2,2) = -31;
As(end-1,end-1) = -31;
As =-As; 

A1 = kron(kron(I,As),C);A2 = kron(kron(As,I),C);A = -(A1+A2);

% Create matrices for solving linear system
k = dt/2000;
M1 = (Id-k*A);
M4 = (25*Id - 12*dt*A);

[L1,U1] = lu(M1); [L4,U4] = lu(M4); 

%% Time Evolution 

tic

% Generate initial solution values with SBDF with very small time step
timep = linspace(0,3*dt,6001);
tlenp = length(timep);

w_olds=w_old;
F_old = F(w_old);

for j = 2:tlenp  
% SBDF1
F_olds = F(w_olds);
w_olds = L1\(w_olds + k*F_olds);
w_olds = U1\w_olds;
    % store corresponding intermediate solutions
    if abs(timep(j)-dt)<k
        w_old1 = w_olds;
        F_old1 = F(w_old1);
    elseif abs(timep(j)-2*dt)<k
         w_old2 = w_olds;
         F_old2 = F(w_old2);
    end
end
 w_old3 = w_olds;
 

for i = 5:tlen   
% SBDF4
F_old3 = F(w_old3); 
w_old4 = L4\(48*w_old3- 36*w_old2 + 16*w_old1-3*w_old+ dt*( 48*F_old3 - 72*F_old2 +48*F_old1-12*F_old));
w_old4 = U4\w_old4;

% Update solution
w_old=w_old1;
w_old1=w_old2;
w_old2 = w_old3;
w_old3 = w_old4;

% Update function values
F_old = F_old1;
F_old1 = F_old2;
F_old2 = F_old3;
end

runtime = toc;

 u_soln = w_old4(1:2:nb-1); 
 v_soln = w_old4(2:2:nb);
 U = reshape(u_soln,steps,steps); V = reshape(v_soln,steps,steps);


 %% Plots
% figure
% contourf(x,y,U')
%  title('\bf\fontsize{20} U solution ')
%  colorbar
% 
% figure
% contourf(x,y,V')
%  title('\bf\fontsize{20} V solution ')
% colorbar


% %****************function calls**************************************
function Fr = F(U)
 Fr = zeros(nb,1);
 u = U(1:2:nb-1); v = U(2:2:nb);
 f1 = aparm+u.^2.*v -(bparm+1)*u;
 f2 = bparm*u-u.^2.*v;
 Fr(1:2:nb-1) = f1; Fr(2:2:nb) = f2;
end




end