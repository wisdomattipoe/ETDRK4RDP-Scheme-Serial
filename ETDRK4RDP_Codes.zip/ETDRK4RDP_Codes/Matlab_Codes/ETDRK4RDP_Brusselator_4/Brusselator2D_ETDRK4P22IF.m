%% Solution to 2D Brusselator Using  split ETD RDP scheme with Integrating factor
% Ref:Zegeling et al (2004)(see attached paper for details on initial and 
% boundary conditions
% E.O Asante-Asamani
% 05/08/2014

function [runtime,u_soln] = Brusselator2D_ETDRK4P22IF(dt,steps)
 clc; close all

% dt: time step
% steps: Number of nodes

%% Model Paramters and initial conditions
aparm = 1; bparm = 3.4;

% diffusion coefficient
epsln1 = 2.e-3; epsln2 = 2.e-3;

% create nodes
x = linspace(0,1,steps); 
h = x(2)-x(1);
y = x;
nnodes = steps^2;
nodes = zeros(nnodes,2);
j = 1;
for k = 1 : steps
        for i = 1:steps
               nodes(j,:) = [x(i) y(k)];
            j = j+1;
        end
end
nb = 2*nnodes; % becuase we are solving a system of 2 RDE

% discretize time interval
t = 0:dt:2; tlen = length(t);

% initial condition for u
u_old = 0.5 + nodes(:,2); 

% initial condition for v
v_old = 1 + 5*nodes(:,1); 

% Stacking nodes for evolution
w_old = zeros(nb,1);
w_old(1:2:nb-1) = u_old; w_old(2:2:nb) = v_old; 

%% Block matrix Assembly
% Poles and weights of partial fraction decomposition
c1 = -3+sqrt(3)*1i; w11 = -6-6*sqrt(3)*1i;
c2 = -6+2*sqrt(3)*1i; w21 = -0.5-(5*sqrt(3)/6)*1i;
w31 = -(sqrt(3)/6)*1i; w41 = 0.5 + (sqrt(3)/6)*1i;
w51 = -(sqrt(3)/12)*1i;

% Second order diffusion matrix
% C = zeros(2);
% C(1,1) = epsln1/h^2;
% C(2,2) = epsln2/h^2;
% Q = blktridiag(2,-1,-1,steps);
% Q(1,2) = -2; Q(steps,steps-1) = -2; I = eye(steps);
% A1 = kron(kron(I,Q),C);A2 = kron(kron(Q,I),C);
% Id = sparse(eye(nb)); 

% Fourth order diffusion matrix
C = zeros(2);
C(1,1) = (epsln1)/(12*h^2);
C(2,2) = (epsln2)/(12*h^2);
e = ones(steps,1); Id = speye(nb);I = eye(steps);
As = spdiags([-e 16*e -30*e 16*e -e], -2:2, steps, steps); % finite difference diffusion operator

% first and last row
As(1,2) =  32;
As(end,end-1) = 32;
As(1,3) = -2;
As(end,end-2) = -2;

% second and second to last row
As(2,2) = -31;
As(end-1,end-1) = -31;
As =-As; 

A1 = kron(kron(I,As),C);A2 = kron(kron(As,I),C);

% Create matrices for solving linear system
M1 = (dt*A1 - c1*Id); M2 = (dt*A1 - c2*Id); M3 = (dt*A2 - c1*Id); M4 = (dt*A2 - c2*Id);

% LU Decomposition of matrices
[L1,U1] = lu(M1); [L2,U2] = lu(M2); [L3,U3] = lu(M3); [L4,U4] = lu(M4);

%% Time Evolution 

tic
for i = 1:tlen-1
    
% Stage 1 Solve for an
Fold = F(w_old); 
an1 = L4\(2*w11*w_old + 24*w51*dt*Fold);
an1 = U4\an1;
an2 = w_old + 2*real(an1);
an3 = L2\(2*w11*an2);
an3 = U2\an3;
an = an2 + 2*real(an3);
Fan = F(an);

% Stage 2 Solve for bn
bn1 = L4\(2*w11*w_old);
bn1 = U4\bn1;
bn2 = L4\(24*w51*dt*Fan);
bn2 = U4\bn2;
bn3 = w_old + 2*real(bn1);
bn4 = L2\(2*w11*bn3);
bn4 = U2\bn4;
bn = bn3 + 2*real(bn4)+ 2*real(bn2);
Fbn = F(bn);

% Stage 3 Solve for cn
% Processor 1
cn1 = L4\(2*w11*an + 48*w51*dt*Fbn);
cn1 = U4\cn1;
% Processor 2
cn2 = L4\(24*w51*dt*Fold);
cn2 = U4\cn2;
cnstar1 = an + 2*real(cn1);
cnstar2 = 2*real(cn2);
% Processor 1
cn3 = L2\(2*w11*cnstar1);
cn3 = U2\cn3;
% Processor 2
cn4 = L1\(w11*cnstar2);
cn4 = U1\cn4;
cn = cnstar1 + 2*real(cn3)- (cnstar2 + 2*real(cn4));
Fcn = F(cn);

% Update future solution
Gn = Fan+Fbn;
% Processor 1
wn1 = L3\(w11*w_old + w21*dt*Fold);
wn1 = U3\wn1;
% Processor 2
wn2 = L3\(4*w31*dt*Gn);
wn2 = U3\wn2;
% Processor 3
wn3 = L3\(w41*dt*Fcn);
wn3 = U3\wn3;
wstar1 = w_old + 2*real(wn1);
wstar2 = 2*real(wn2);
wstar3 = 2*real(wn3);
% Processor 1
wn4 = L1\(w11*wstar1);
wn4 = U1\wn4;
% Processor 2
wn5 = L2\(2*w11*wstar2);
wn5 = U2\wn5;

w_old = wstar1 + wstar2 + wstar3 + 2*real(wn4) + 2*real(wn5);
end

runtime = toc;

 u_soln = w_old(1:2:nb-1); 
 v_soln = w_old(2:2:nb);
 U = reshape(u_soln,steps,steps); V = reshape(v_soln,steps,steps);


 %% Plots
% figure
% contourf(x,y,U')
%  %title('\bf\fontsize{20} U solution ')
%  colorbar
% 
% figure
% contourf(x,y,V')
%  %title('\bf\fontsize{20} V solution ')
% colorbar




% %****************function calls**************************************
function Fr = F(U)
 Fr = zeros(nb,1);
 u = U(1:2:nb-1); v = U(2:2:nb);
 f1 = aparm+u.^2.*v -(bparm+1)*u;
 f2 = bparm*u-u.^2.*v;
 Fr(1:2:nb-1) = f1; Fr(2:2:nb) = f2;
end




end