%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Author: Wisdom K. Attipoe
%%% Date: 8/1/2024 

function [runtime, errorval, Anet] = ETD4RK_RDP1(dt,steps)
clc; close all

%%% Time step %%%
k = dt;

%%%%%%%%%%%%%%%% constants %%%%%%%%%%%%%%%%%%%%%%%%%
b1 = 0.4751834017787114;
b2 = 1;
b3 = 0.3888888888888889;
b4 = 0.7155553412275962;

w1 = 20.10707940496431;
w2 = 0.5229558818011362;
w3 = -15.21083750434353;
w4 = -4.419197782421921;

a1 = w1*(b2+b3+b4) + w2*(b1+b3+b4)+ w3*(b1+b2+b4)+ w4*(b1+b2+b3);
a2 = w1*(b2*b3 + (b2+b3)*b4) + w2*(b1*b3 + (b1+b3)*b4) + w3*(b1*b2 + (b1+b2)*b4)+ w4*(b1*b2 + (b1+b2)*b3);
a3 = w1*b2*b3*b4 + w2*b1*b3*b4 + w3*b1*b2*b4 + w4*b1*b2*b3;

mu1 = 0.5*(a1 - (b1 + b2 +b3 + b4));
mu2 = 0.25*(a2 - (b1*b2 + b1*b3 + b1*b4 + b2*b3 + b2*b4 + b3*b4));
mu3 = 0.125*(a3 - (b1*b2*b3 + b1*b2*b4 + b1*b3*b4 + b2*b3*b4));
mu4 = -0.0625*(b1*b2*b3*b4);

Q1 = k*(mu1 - 2*(mu2/b1)+ 4*(mu3/(b1)^2) -8*(mu4/(b1)^3))/((1 - b2/b1)*(1 - b3/b1)*(1 - b4/b1));
Q2 = k*(mu1 - 2*(mu2/b2)+ 4*(mu3/(b2)^2) -8*(mu4/(b2)^3))/((1 - b1/b2)*(1 - b3/b2)*(1 - b4/b2));
Q3 = k*(mu1 - 2*(mu2/b3)+ 4*(mu3/(b3)^2) -8*(mu4/(b3)^3))/((1 - b1/b3)*(1 - b2/b3)*(1 - b4/b3));
Q4 = k*(mu1 - 2*(mu2/b4)+ 4*(mu3/(b4)^2) -8*(mu4/(b4)^3))/((1 - b1/b4)*(1 - b2/b4)*(1 - b3/b4));

a11 = b1 + b2 + b3 + b4;                       %%% a11 = alpha
b11 = b1*b2 + b3*b4 + (b1 + b2)*(b3 + b4);     %%% b11 = beta
g11 = (b1 + b2)*(b3*b4) + (b3 + b4)*(b1*b2);   %%% g11 = gamma
r11 = b1*b2*b3*b4;                             %%% r11 = rho

t1 = 4*g11 - b11 - a1 - 3*a2 - 4*a3;           %%% G11 = Gamma or w1
t2 = 4*r11 - g11 - (a2 + 3*a3);                %%% P11 = Phi  or w2
t3  = -(r11 + a3);                             %%% or w3 

N1 = k*(t1 -(t2/b1)+(t3/(b1)^2))/((1 - b2/b1)*(1 - b3/b1)*(1 - b4/b1));   %These 4 are the r_i. So Ni = ri. 
N2 = k*(t1 -(t2/b2)+(t3/(b2)^2))/((1 - b1/b2)*(1 - b3/b2)*(1 - b4/b2));
N3 = k*(t1 -(t2/b3)+(t3/(b3)^2))/((1 - b1/b3)*(1 - b2/b3)*(1 - b4/b3));
N4 = k*(t1 -(t2/b4)+(t3/(b4)^2))/((1 - b1/b4)*(1 - b2/b4)*(1 - b3/b4));

L1 = -(2*g11 - b11 - (2*a3 + a2));
L2 = -(2*r11 - g11 - a3);
L3 = r11;

G1 = k*(L1 - (L2/b1) + (L3/(b1)^2))/((1 - b2/b1)*(1 - b3/b1)*(1 - b4/b1));
G2 = k*(L1 - (L2/b2) + (L3/(b2)^2))/((1 - b1/b2)*(1 - b3/b2)*(1 - b4/b2));
G3 = k*(L1 - (L2/b3) + (L3/(b3)^2))/((1 - b1/b3)*(1 - b2/b3)*(1 - b4/b3));
G4 = k*(L1 - (L2/b4) + (L3/(b4)^2))/((1 - b1/b4)*(1 - b2/b4)*(1 - b3/b4));

M1 = -(-4*g11 + 3*b11 - a11 + (a2 + 4*a3));
M2 = -(-4*r11 +3*g11 - b11 + a3);
M3 = -(3*r11 - g11);
M4 = r11;

H1 = k*(M1 - (M2/b1) + (M3/(b1)^2) - (M4/(b1)^3))/((1 - b2/b1)*(1 - b3/b1)*(1 - b4/b1));
H2 = k*(M1 - (M2/b2) + (M3/(b2)^2) - (M4/(b2)^3))/((1 - b1/b2)*(1 - b3/b2)*(1 - b4/b2));
H3 = k*(M1 - (M2/b3) + (M3/(b3)^2) - (M4/(b3)^3))/((1 - b1/b3)*(1 - b2/b3)*(1 - b4/b3));
H4 = k*(M1 - (M2/b4) + (M3/(b4)^2) - (M4/(b4)^3))/((1 - b1/b4)*(1 - b2/b4)*(1 - b3/b4));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% create nodes in 2D
x = linspace(-0.5*pi,0.5*pi,steps+2); 
h = x(2)-x(1);
xint = x(2:end-1); yint=xint;
nnodes = steps^2;
nodes = zeros(nnodes,2);

j = 1;
for k_ind = 1 : steps
        for i = 1:steps
               nodes(j,:) = [xint(i) yint(k_ind)];
            j = j+1;
        end
end

% discretize time interval
T = 1;
t = 0:dt:T; 
tlen = length(t);


%%% Formulate system matrices 4th order with 4th order extrapolation
d1 = 1; %Diffusion coefficient for the PDE problem 1
r2 = d1/(12*h^2);
e = ones(steps,1); 
%Id = speye(nnodes);
I = speye(steps);
As = spdiags([-e 16*e -30*e 16*e -e], -2:2, steps, steps); % finite difference diffusion operator
As(1,1) =  -20;
As(end,end) = -20;
As(1,2) = 6;
As(end,end-1) = 6;
As(1,3) = 4;
As(end,end-2) = 4;
As(1,4) = -1;
As(end,end-3) =-1;


Arr = As;

As =-r2*As; 
A1 = kron(I,As); A2 = kron(As,I); A = A1+A2;

Ar1 = kron(I,Arr); Ar2 = kron(Arr,I); Anet = Ar1+Ar2;

% initial condition for w_old(continuous)
I = speye(steps^2);
w_old = zeros(nnodes,1);
for i = 1: nnodes
 pn = nodes(i,:); % extract point
 xn = pn(1);
 yn = pn(2);
 w_old(i) = cos(xn)*cos(yn);
end


%%% Matrix set up for linear systems %%%
A1A = (I + (b1/2)*k*A);
A2A = (I + (b2/2)*k*A);
A3A = (I + (b3/2)*k*A);
A4A = (I + (b4/2)*k*A);

A11 = (I + b1*k*A);
A12 = (I + b2*k*A);
A13 = (I + b3*k*A);
A14 = (I + b4*k*A);

%%%%%% LU factorization of the system matricies %%%%
[L1, U1] = lu(A1A);
[L2, U2] = lu(A2A);
[L3, U3] = lu(A3A);
[L4, U4] = lu(A4A);


[L11, U11] = lu(A11);
[L22, U22] = lu(A12);
[L33, U33] = lu(A13);
[L44, U44] = lu(A14);

%L1A = full(L1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



tic
for i = 2:tlen
    
Fold = F(w_old); 

%%%%%%%%%%%% system 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% J1a = A1A\(w1*w_old - Q1*Fold);   old system solvers but were slow
J1a = L1\(w1*w_old - Q1*Fold);
J1a = U1\J1a;

%J2a = A2A\(w2*w_old - Q2*Fold);
J2a = L2\(w2*w_old - Q2*Fold);
J2a = U2\J2a;

%J3a = A3A\(w3*w_old - Q3*Fold);
J3a = L3\(w3*w_old - Q3*Fold);
J3a = U3\J3a;

%J4a = A4A\(w4*w_old - Q4*Fold);
J4a = L4\(w4*w_old - Q4*Fold);
J4a = U4\J4a;

an = J1a + J2a +J3a + J4a;

%%%%%%%%%%%%%%% system 2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Fold1 = F(an);
%J1b = A1A\(w1*w_old - Q1*Fold1);
J1b = L1\(w1*w_old - Q1*Fold1);
J1b = U1\J1b;

%J2b = A2A\(w2*w_old - Q2*Fold1);
J2b = L2\(w2*w_old - Q2*Fold1);
J2b = U2\J2b;

%J3b = A3A\(w3*w_old - Q3*Fold1);
J3b = L3\(w3*w_old - Q3*Fold1);
J3b = U3\J3b;

%J4b = A4A\(w4*w_old - Q4*Fold1);
J4b = L4\(w4*w_old - Q4*Fold1);
J4b = U4\J4b;

bn = J1b + J2b +J3b + J4b;

%%%%%%%%%%%%% system 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Fold2 = F(bn);
%J1c = A1A\(w1*an - Q1*(2*Fold2 - Fold));
J1c = L1\(w1*an - Q1*(2*Fold2 - Fold));
J1c = U1\J1c;

%J2c = A2A\(w2*an - Q2*(2*Fold2 - Fold));
J2c = L2\(w2*an - Q2*(2*Fold2 - Fold));
J2c = U2\J2c;

%J3c = A3A\(w3*an - Q3*(2*Fold2 - Fold));
J3c = L3\(w3*an - Q3*(2*Fold2 - Fold));
J3c = U3\J3c;

%J4c = A4A\(w4*an - Q4*(2*Fold2 - Fold));
J4c = L4\(w4*an - Q4*(2*Fold2 - Fold));
J4c = U4\J4c;

cn = J1c + J2c +J3c + J4c;

%%%%%%%%% Final Solution system %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Fold3 = F(cn); 
%Y1 = A11\(w1*w_old +N1*Fold + 2*G1*(Fold1 + Fold2) + H1*Fold3);
Y1 = L11\(w1*w_old +N1*Fold + 2*G1*(Fold1 + Fold2) + H1*Fold3);
Y1 = U11\Y1;

%Y2 = A12\(w2*w_old +N2*Fold + 2*G2*(Fold1 + Fold2) + H2*Fold3);
Y2 = L22\(w2*w_old +N2*Fold + 2*G2*(Fold1 + Fold2) + H2*Fold3);
Y2 = U22\Y2;

%Y3 = A13\(w3*w_old +N3*Fold + 2*G3*(Fold1 + Fold2) + H3*Fold3);
Y3 = L33\(w3*w_old +N3*Fold + 2*G3*(Fold1 + Fold2) + H3*Fold3);
Y3 = U33\Y3;

%Y4 = A14\(w4*w_old +N4*Fold + 2*G4*(Fold1 + Fold2) + H4*Fold3);
Y4 = L44\(w4*w_old +N4*Fold + 2*G4*(Fold1 + Fold2) + H4*Fold3);
Y4 = U44\Y4;

un1 = Y1+Y2+Y3+Y4;

% Update solution
w_old = un1;

end
runtime = toc;


% Compute exact solution
u_exact = zeros(nnodes,1);
for p = 1:nnodes
    xp = nodes(p,1);
    yp = nodes(p,2);
    u_exact(p) = cos(xp)*cos(yp)*exp(-3*T);
end


% Return maximum error (infinity norm of the vector)
errorval = max(abs((u_exact-un1)));
%errorval = norm(u_exact - un1)*h;

%%%%%%%%%%%%%% Plot numerical solution

% U = zeros(steps+2);
% U(2:steps+1,2:steps+1) = reshape(w_old,steps,steps);
% y = x;
% figure(2)
% surf(x,y,U')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Numerical Solution ')
% colorbar
% 
% 
% %%%%%%%%%%%%% Plot exact solution
% Uexact=zeros(steps+2);
% Uexact(2:steps+1,2:steps+1) = reshape(u_exact,steps,steps);
% y = x;
% figure(3)
% surf(x,y,Uexact')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Exact Solution ')
% colorbar


% 
% %%%%%%%%%%%% Plot computational error 
% 
% Uerror=zeros(steps+2);
% u_error = abs(u_exact-w_old);
% Uerror(2:steps+1,2:steps+1) = reshape(u_error,steps,steps);
% y = x;
% figure(4)
% surf(x,y,Uerror')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Numerical Error')
% colorbar



 %****************function calls**************************************
function Fr = F(u)
    Fr = -u;
end

end