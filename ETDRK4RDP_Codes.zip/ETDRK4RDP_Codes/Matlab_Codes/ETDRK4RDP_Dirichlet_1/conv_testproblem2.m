% function to compute error and convergence rates

function [conv,errorvec]=conv_testproblem2(error1,error2,error3,error4,step)

 
%initialize variables
errorvec = [error1, error2,error3,error4]; 
conv = zeros(4,1);

%calculate rate of convergence
conv(1)=0;
for i = 2:4
    conv(i) = (log(errorvec(i-1)/errorvec(i)))/(log(step(i-1)/step(i)));
end
