%% Solution to 2D problem with exacts solution using ETDRK4P04_TP3
% Wisdom K. Attipoe
% 08/21/2024

function [runtime,w_old] = ETDRK4P04_TP3(dt,steps)
 
clc; close all
% dt: time step
% steps: number of interior spatial points in each coordinate direction

%% Model Paramters and initial conditions

% diffusion coefficient
d1 = 0.25;


% create nodes
x = linspace(0,1,steps+2);
h = x(2)-x(1);
xint = x(2:end-1); yint=xint;
nnodes = steps^2;
nodes = zeros(nnodes,2);


j = 1;
for k = 1 : steps
        for i = 1:steps
               nodes(j,:) = [xint(i) yint(k)];
            j = j+1;
        end
end

% discretize time interval
T = 1;
t = 0:dt:T; 
tlen = length(t);

%initial condition for w_old(continuous)
w_old = zeros(nnodes,1);
for i = 1: nnodes
 pn = nodes(i,:); % extract point
 xn = pn(1);
 yn = pn(2);
 w_old(i) = sin(pi*xn)*sin(pi*yn);
end

% % Poles and weights of partial fraction decomposition
% c1 = -1.72944423106769 + 0.888974376121862*1i; 
% c2 = -0.270555768932292 - 2.50477590436244*1i;
% w1 = 0.541413348429182 - 1.58885918222330*1i;
% w2 = -0.541413348429154 - 0.248562520866115*1i;
% w11 = 0.244153693956274 - 0.0497524711964030*1i;
% w12 = -0.244153693956268 - 0.0750708534900480*1i;
% w21 = -0.0240066687966667 - 0.210771761184790*1i;
% w22 = 0.0240066687966698 + 0.110830774318527*1i;
% w31 = 0.473042583717175 + 0.293424221840328*1i;
% w32 = 0.0269574162828241 - 0.165188084403066*1i;
% 
% 
% c11 = -3.45888846213543 - 1.77794875224371*1i;    %tilda terms 
% c22 = -0.541111537864595 - 5.00955180872487*1i;
% w1w = 1.08282669685827 + 3.17771836444659*1i;
% w2w = -1.08282669685831 - 0.497125041732246*1i;
% OMEGA1 = -0.621169602486758 - 0.599415294095229*1i;
% OMEGA2 = 0.121169602486770 - 0.203064159380992*1i;

% Poles and weights of partial fraction decomposition
c1 = -1.72944423106769 + 0.888974376121862*1i; 
c2 = -0.270555768932292 + 2.50477590436244*1i;
w1 = 0.541413348429182 - 1.58885918222330*1i;
w2 = -0.541413348429154 + 0.248562520866115*1i;        %Im edited to +
w11 = 0.244153693956274 - 0.0497524711964030*1i;
w12 = -0.244153693956268 + 0.0750708534900480*1i;      %Im edited to +
w21 = -0.0240066687966667 - 0.210771761184790*1i;
w22 = 0.0240066687966698 - 0.110830774318527*1i;        %Im edited to -
w31 = 0.473042583717175 + 0.293424221840328*1i;
w32 = 0.0269574162828241 + 0.165188084403066*1i;        %Im edited to +

 %tilda terms 
c11 = -3.45888846213543 + 1.77794875224371*1i;         %Im edited to +
c22 = -0.541111537864595 + 5.00955180872487*1i;        %Im edited to +
%w1w = 1.08282669685827 + 3.17771836444659*1i;
%w2w = -1.08282669685831 - 0.497125041732246*1i;
w1w = 2*w1;
w2w = 2*w2;
OMEGA1 = 0.621169602486758 - 0.599415294095229*1i;     %Re edited to +
OMEGA2 = -0.121169602486770 - 0.203064159380992*1i;    %%Im edited to -

%%  Matrix Assembly%% 
% Formulate system matrices 4th order SD with 4th order Lagrange extrapolation
% Formulate system matrices
r2=d1/(12*h^2);
e = ones(steps,1); 
Id = speye(nnodes);
I = speye(steps);
As = spdiags([-e 16*e -30*e 16*e -e], -2:2, steps, steps); % finite difference diffusion operator
As(1,1) =  -20;
As(end,end) = -20;
As(1,2) = 6;
As(end,end-1) = 6;
As(1,3) = 4;
As(end,end-2) = 4;
As(1,4) = -1;
As(end,end-3) =-1;
As =-r2*As; 
A1 = kron(I,As); A2 = kron(As,I); A = A1+A2;


%Set up the matrices for solving the linear system
M1 = (dt*A - c11*Id); 
M2 = (dt*A - c22*Id); 

M11 = (dt*A - c1*Id);  
M22 = (dt*A - c2*Id);

%%%%%% LU factorization of the system matricies %%%%
[L1, U1] = lu(M1);
[L2, U2] = lu(M2);


[L3, U3] = lu(M11);
[L4, U4] = lu(M22);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


tic
for i = 2:tlen
    
Fold = F(w_old);

%%%%%%%%%%%%%%%%%%% system 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Na1 = M1\(w1w*w_old + OMEGA1*dt*Fold);
Na1 = L1\(w1w*w_old + OMEGA1*dt*Fold);
Na1 = U1\Na1;

%Na2 = M2\(w2w*w_old + OMEGA2*dt*Fold);
Na2 = L2\(w2w*w_old + OMEGA2*dt*Fold);
Na2 = U2\Na2;

an = 2*(real(Na1) + real(Na2));

%%%%%%%%%%%%%%%%%% system 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Fold1 = F(an);

%Nb1 = M1\(w1w*w_old + OMEGA1*dt*Fold1);
Nb1 = L1\(w1w*w_old + OMEGA1*dt*Fold1);
Nb1 = U1\Nb1;

%Nb2 = M2\(w2w*w_old + OMEGA2*dt*Fold1);
Nb2 = L2\(w2w*w_old + OMEGA2*dt*Fold1);
Nb2 = U2\Nb2;

bn = 2*(real(Nb1) + real(Nb2));

%%%%%%%%%%%%%%%%% system 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Fold2 = F(bn);

%Nc1 = M1\(w1w*an + OMEGA1*dt*(2*Fold2 - Fold));
Nc1 = L1\(w1w*an + OMEGA1*dt*(2*Fold2 - Fold));
Nc1 = U1\Nc1;

%Nc2 = M2\(w2w*an + OMEGA2*dt*(2*Fold2 - Fold));
Nc2 = L2\(w2w*an + OMEGA2*dt*(2*Fold2 - Fold));
Nc2 = U2\Nc2;

cn = 2*(real(Nc1) + real(Nc2));

%%%%%%%%%%%%%%%%%% Final solution solve %%%%%%%%%%%%%%%%%%%%%%
Fold3 = F(cn);

%Nu1 = M11\(w1*w_old + dt*w11*Fold + 2*dt*w21*(Fold1 + Fold2) + dt*w31*Fold3);
Nu1 = L3\(w1*w_old + dt*w11*Fold + 2*dt*w21*(Fold1 + Fold2) + dt*w31*Fold3);
Nu1 = U3\Nu1;

%Nu2 = M22\(w2*w_old + dt*w12*Fold + 2*dt*w22*(Fold1 + Fold2) + dt*w32*Fold3);
Nu2 = L4\(w2*w_old + dt*w12*Fold + 2*dt*w22*(Fold1 + Fold2) + dt*w32*Fold3);
Nu2 = U4\Nu2;

un1 = 2*(real(Nu1) + real(Nu2));

w_old = un1;
end

runtime = toc;

% Compute exact solution
% u_exact = zeros(nnodes,1);
% for p = 1:nnodes
%     xp = nodes(p,1);
%     yp = nodes(p,2);
%     u_exact(p) = cos(xp)*cos(yp)*exp(-3*T);
% end

% Return maximum error
%errorval = max(abs((u_exact-un1)));

% % Plot numerical solution
% U = zeros(steps+2);
% U(2:steps+1,2:steps+1) = reshape(w_old,steps,steps);
% y = x;
% figure(2)
% surf(x,y,U')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Numerical Solution ')
% colorbar
% % 
% % Plot exact solution
% Uexact=zeros(steps+2);
% Uexact(2:steps+1,2:steps+1) = reshape(u_exact,steps,steps);
% y = x;
% figure(3)
% surf(x,y,Uexact')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Exact Solution ')
% colorbar
% 
% 
% 
% % % Plot computational error 
% 
% Uerror=zeros(steps+2);
% u_error = abs(u_exact-w_old);
% Uerror(2:steps+1,2:steps+1) = reshape(u_error,steps,steps);
% y = x;
% figure(4)
% surf(x,y,Uerror')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Numerical Error')
% colorbar
% 
% 
% 
%****************function calls**************************************
function Fr = F(u)
    Fr = -u./(1+u);
end

end