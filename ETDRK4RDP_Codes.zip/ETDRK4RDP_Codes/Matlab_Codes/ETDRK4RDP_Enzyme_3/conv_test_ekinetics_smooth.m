% Experiment to compute rate of convergence of ETDRK4P22-IF in comparison with
% fourth order ETD schemes for Example 3.3
% March 2024

clc;clear
% Time steps
k1=0.1;k2=0.05;k3=0.025;k4=0.0125;k5 =0.00625;

% Mesh size
h1=19; h2=h1; h3=h1; h4=h1; h5=h1;
step = [k1,k2,k3,k4];space=[h1,h2,h3,h4];

%% results for ETDRDP-IF
[runtime1,soln1] = ETD4RK_RDP_TP3(k1,h1);
[runtime2,soln2] = ETD4RK_RDP_TP3(k2,h2);
[runtime3,soln3] = ETD4RK_RDP_TP3(k3,h3);
[runtime4,soln4] = ETD4RK_RDP_TP3(k4,h4);
[~,soln5] = ETD4RK_RDP_TP3(k5,h5);

TimeRDPRK4=[runtime1,runtime2,runtime3,runtime4];
[convRDPRK4,errorRDPRK4]=conv_ekinetics_finegrid(soln1,soln2,soln3,soln4,soln5,step);

%% results for ETDRK4P22 
[runtime1,soln1] = enzymekinetics_2DS4_ETDRK4P22(k1,h1);
[runtime2,soln2] = enzymekinetics_2DS4_ETDRK4P22(k2,h2);
[runtime3,soln3] = enzymekinetics_2DS4_ETDRK4P22(k3,h3);
[runtime4,soln4] = enzymekinetics_2DS4_ETDRK4P22(k4,h4);
[runtime5,soln5] = enzymekinetics_2DS4_ETDRK4P22(k5,h5);

TimeRK4P22=[runtime1,runtime2,runtime3,runtime4];
[convRK4P22,errorRK4P22]=conv_ekinetics_finegrid(soln1,soln2,soln3,soln4,soln5,step);

%% results for ETDRK4P22-IF 
[runtime1,soln1] = ETDRK4P04_TP3(k1,h1);
[runtime2,soln2] = ETDRK4P04_TP3(k2,h2);
[runtime3,soln3] = ETDRK4P04_TP3(k3,h3);
[runtime4,soln4] = ETDRK4P04_TP3(k4,h4);
[runtime5,soln5] = ETDRK4P04_TP3(k5,h5);

TimeETDRK4P04=[runtime1,runtime2,runtime3,runtime4];
[convRK4P04,errorRK4P04]=conv_ekinetics_finegrid(soln1,soln2,soln3,soln4,soln5,step);

%% results for SBDF4
% [runtime1,soln1] = enzymekinetics_2DS4_SBDF4(k1,h1);
% [runtime2,soln2] = enzymekinetics_2DS4_SBDF4(k2,h2);
% [runtime3,soln3] = enzymekinetics_2DS4_SBDF4(k3,h3);
% [runtime4,soln4] = enzymekinetics_2DS4_SBDF4(k4,h4);
% [runtime5,soln5] = enzymekinetics_2DS4_SBDF4(k5,h5);
% 
% TimeSBDF4=[runtime1,runtime2,runtime3,runtime4];
% [convSBDF4,errorSBDF4]=conv_ekinetics_finegrid(soln1,soln2,soln3,soln4,soln5,step);
%% Produce Efficiency and Convergence plots

%ETD Comparison
 Time_mat = [TimeRDPRK4;TimeRK4P22;TimeETDRK4P04];
 Error_mat = [errorRDPRK4;errorRK4P22;errorRK4P04];

efficiency_plot_ekinetics_smooth(Time_mat,Error_mat)
convergence_plot_ekinetics_smooth(step,Error_mat)
%% Display results

fprintf('\n Results for ETDRDPRK4\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/(space(i)),errorRDPRK4(i),convRDPRK4(i),TimeRDPRK4(i))
end
fprintf(' Results for ETDRK2P22\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorRK4P22(i),convRK4P22(i),TimeRK4P22(i))
end
fprintf(' Results for ETDRK4P04\n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorRK4P04(i),convRK4P04(i),TimeETDRK4P04(i))
end
% fprintf(' Results for SBDF4\n')
% fprintf('k             h            error        conv       Time \n');
% for i = 1:4
%     fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),pi/space(i),errorSBDF4(i),convSBDF4(i),TimeSBDF4(i))
% end
