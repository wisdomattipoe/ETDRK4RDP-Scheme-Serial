%% Solution to 2D problem with exact solution and Neumann boundary condition using ETDRK4P22
% E.O Asante-Asamani
% 05/04/2023

function [runtime,errorval] = testproblem3_2D_ETDRK4P22(dt,steps)
 
clc; close all
% dt: time step
% steps: number of spatial points in each coordinate direction

%% Model Paramters and initial conditions

% diffusion coefficient
d1 = 1; 

% create nodes
x = linspace(-pi,pi,steps);
h = x(2)-x(1);
xint = x; yint=x;
nnodes = steps^2;
nodes = zeros(nnodes,2);

j = 1;
for k = 1 : steps
        for i = 1:steps
               nodes(j,:) = [xint(i) yint(k)];
            j = j+1;
        end
end

% discretize time interval
T = 1;
t = 0:dt:T; tlen = length(t);

% initial condition for w_old(continuous)
w_old = zeros(nnodes,1);
for i = 1: nnodes
 pn = nodes(i,:); % extract point
 xn = pn(1);
 yn = pn(2);
 w_old(i) = cos(xn)*cos(yn);
end

%plot initial condition
% Uinit = zeros(steps+2);
% Uinit(2:steps+1,2:steps+1) = reshape(w_old,steps,steps);
% y = x;
% figure(1)
% surf(x,y,Uinit')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Numerical Solution ')
% colorbar


%%  Matrix Assembly
% Poles and weights of partial fraction decomposition
c1 = -3+sqrt(3)*1i; w11 = -6-6*sqrt(3)*1i;
c2 = -6+2*sqrt(3)*1i; w21 = -0.5-(5*sqrt(3)/6)*1i;
w31 = -(sqrt(3)/6)*1i; w41 = 0.5 + (sqrt(3)/6)*1i;
w51 = -(sqrt(3)/12)*1i;

% Formulate system matrices 2nd order
% e = ones(steps,1); Id = sparse(eye(nnodes));I = eye(steps);
% As = (d1/h^2)*spdiags([-e 2*e -e], -1:1, steps, steps); % finite difference diffusion operator
% A1 = kron(I,As); A2 = kron(As,I); A = A1+A2;

% Formulate system matrices 4th order with 4th order extrapolation
r2=d1/(12*h^2);
e = ones(steps,1); Id = speye(nnodes);I = eye(steps);
As = spdiags([-e 16*e -30*e 16*e -e], -2:2, steps, steps); % finite difference diffusion operator
% first and last row
As(1,2) =  32;
As(end,end-1) = 32;
As(1,3) = -2;
As(end,end-2) = -2;

% second and second to last row
As(2,2) = -31;
As(end-1,end-1) = -31;
As =-r2*As; 
A1 = kron(I,As); A2 = kron(As,I); A = A1+A2;

% Create matrices for solving linear system
M1 = (dt*A - c1*Id); M2 = (dt*A - c2*Id); 
%% Time Evolution
%hw = waitbar(0,'Simulating...');
[L1,U1] = lu(M1); [L2,U2] = lu(M2);

tic
for i = 2:tlen
    
Fold = F(w_old); 

% Stage 1 linear solve
an1 = L2\(2*w11*w_old + 24*w51*dt*Fold);
an1 = U2\an1;
an = w_old + 2*real(an1);

% Stage 2 linear solve
Fan = F(an);
bn1 = L2\(2*w11*w_old +24*w51*dt*Fan);
bn1 = U2\bn1;
bn = w_old + 2*real(bn1);

% Stage 3 linear solve
Fbn = F(bn);
cn1 = L2\(2*w11*an +24*w51*dt*(2*Fbn-Fold));
cn1 = U2\cn1;
cn = an + 2*real(cn1);

% Stage 4 linear solves
Gn = Fan+Fbn;
Fcn = F(cn);
wn1 = L1\(w11*w_old + dt*(w21*Fold + 4*w31*Gn + w41*Fcn));
wn1 = U1\wn1;

% Update solution
w_old = w_old + 2*real(wn1);

end

runtime = toc;
%%
% Compute exact solution
u_exact = zeros(nnodes,1);
for p = 1:nnodes
    xp = nodes(p,1);
    yp = nodes(p,2);
    u_exact(p) = cos(xp)*cos(yp)*exp(-3*T);
end

% Return maximum error
 errorval = max(abs((u_exact-w_old)));

%% Plot numerical solution
% % 
% U = reshape(w_old,steps,steps);
% y = x;
% figure(2)
% surf(x,y,U')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% %title('\bf\fontsize{20} Numerical Solution ')
% colorbar
% 
% % Plot exact solution
% 
% Uexact = reshape(u_exact,steps,steps);
% y = x;
% figure(3)
% surf(x,y,Uexact')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% %title('\bf\fontsize{20} Exact Solution ')
% colorbar



% % % Plot computational error 
% 
% Uerror=zeros(steps+2);
% u_error = abs(u_exact-w_old);
% Uerror(2:steps+1,2:steps+1) = reshape(u_error,steps,steps);
% y = x;
% figure(4)
% surf(x,y,Uerror')
% xlabel('x')
% ylabel('y')
% zlabel('U')
% title('\bf\fontsize{20} Numerical Error')
% colorbar



%****************function calls**************************************
function Fr = F(u)
    Fr = -u;
    %Fr = (2*pi^2-3)*u;
end


end