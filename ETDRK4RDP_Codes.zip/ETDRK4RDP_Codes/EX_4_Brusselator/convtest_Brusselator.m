% Convergence test for ETDRK4_RDP for Test_Problem 5 (Brusellator Problem)
% September 2024
% Author: Wisdom K. Attipoe


clc;clear
% % Initial parameters
%  k1=0.05;k2=0.025;k3=0.0125;k4=0.00625;kref=0.003125;
k1 = 0.2; k2 = 0.1; k3=0.05; k4 = 0.025; kref=0.0125;  %%% Updated k's to ensure convergence

% Spatial Mesh
h1 = 81; h2 = h1; h3=h1; h4=h1;href = h1;
 step = [k1,k2,k3,k4];
 space=[1/(h1-1),1/(h2-1),1/(h3-1),1/(h4-1),1/(href-1)];
 

%% results for ETDRK4_RDP
[runtime1,soln1] = Brusselator2D_ETD4RK_RDP1(k1,h1);
[runtime2,soln2] = Brusselator2D_ETD4RK_RDP1(k2,h2);
[runtime3,soln3] = Brusselator2D_ETD4RK_RDP1(k3,h3);
[runtime4,soln4] = Brusselator2D_ETD4RK_RDP1(k4,h4);
[~,soln5] = Brusselator2D_ETD4RK_RDP1(kref,href);

solnref2 = soln2; solnref3 = soln3; solnref4=soln4; solnref5=soln5;
 TimeRDPS=[runtime1,runtime2,runtime3,runtime4];
 [convRDPS,errorRDPS]=conv_Brusselator(soln1,soln2,soln3,soln4,solnref2,solnref3,solnref4,solnref5,step); 
 
%% results for ETDRK4P22
[runtime1,soln1] = Brusselator2D_ETDRK4P22(k1,h1);
[runtime2,soln2] = Brusselator2D_ETDRK4P22(k2,h2);
[runtime3,soln3] = Brusselator2D_ETDRK4P22(k3,h3);
[runtime4,soln4] = Brusselator2D_ETDRK4P22(k4,h4);
[runtime5,soln5] = Brusselator2D_ETDRK4P22(kref,href);

solnref2 = soln2; solnref3 = soln3; solnref4=soln4; solnref5=soln5;

 TimeRK4P22=[runtime1,runtime2,runtime3,runtime4];
 [convRK4P22,errorRK4P22]=conv_Brusselator(soln1,soln2,soln3,soln4,solnref2,solnref3,solnref4,solnref5,step);
 
  %% results for ETDRK4P22IF
[runtime1,soln1] = Brusselator2D_ETDRK4P04(k1,h1);
[runtime2,soln2] = Brusselator2D_ETDRK4P04(k2,h2);
[runtime3,soln3] = Brusselator2D_ETDRK4P04(k3,h3);
[runtime4,soln4] = Brusselator2D_ETDRK4P04(k4,h4);
[runtime5,soln5] = Brusselator2D_ETDRK4P04(kref,href);

solnref2 = soln2; solnref3 = soln3; solnref4=soln4; solnref5=soln5;

 TimeRK4P04=[runtime1,runtime2,runtime3,runtime4];
 [convRK4P04,errorRK4P04]=conv_Brusselator(soln1,soln2,soln3,soln4,solnref2,solnref3,solnref4,solnref5,step);
 
%%%% results for SBDF4
% [runtime1,soln1] = Brusselator2D_SBDF4(k1,h1);
% [runtime2,soln2] = Brusselator2D_SBDF4(k2,h2);
% [runtime3,soln3] = Brusselator2D_SBDF4(k3,h3);
% [runtime4,soln4] = Brusselator2D_SBDF4(k4,h4);
% [runtime5,soln5] = Brusselator2D_SBDF4(kref,href);
% 
% solnref2 = soln2; solnref3 = soln3; solnref4=soln4; solnref5=soln5;
% 
%  TimeSBDF4=[runtime1,runtime2,runtime3,runtime4];
%  [convSBDF4,errorSBDF4]=conv_Brusselator(soln1,soln2,soln3,soln4,solnref2,solnref3,solnref4,solnref5,step);

 %% Effiency plot
 
 % Comparison for IMEX Schemes
 Time_mat = [TimeRDPS;TimeRK4P22;TimeRK4P04];
 Error_mat = [errorRDPS;errorRK4P22;errorRK4P04];
 
%  
 efficiency_plot_Brusselator2D(Time_mat,Error_mat)
 convergence_plot_Brusselator2D(step,Error_mat)
 

%% Display results

fprintf(' Results for ETDRK4RDP \n')
fprintf('k             h            error        conv       Time \n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),space(i),errorRDPS(i),convRDPS(i),TimeRDPS(i))
end
fprintf('\nResults for ETDRK4P22\n')
fprintf('k             h            error        conv       Time\n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),space(i),errorRK4P22(i),convRK4P22(i),TimeRK4P22(i))
end
fprintf('\nResults for ETDRK4P04\n')
fprintf('k             h            error        conv       Time\n');
for i = 1:4
    fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),space(i),errorRK4P04(i),convRK4P04(i),TimeRK4P04(i))
end

% fprintf('\nResults for SBDF4\n')
% fprintf('k             h            error        conv       Time\n');
% for i = 1:4
%     fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),space(i),errorSBDF4(i),convSBDF4(i),TimeSBDF4(i))
% end

% 
% fprintf('\nResults for IMEX-TR\n')
% fprintf('k             h            error        conv       Time\n');
% for i = 1:4
%     fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),space(i),errorIMTR(i),convIMTR(i),TimeIMTR(i))
% end
% 
% fprintf('\nResults for IMEX-Adams2\n')
% fprintf('k             h            error        conv       Time\n');
% for i = 1:4
%     fprintf('%.6f   %.6f    %1.4e      %.2f      %.5f\n', step(i),space(i),errorIMAD2(i),convIMAD2(i),TimeIMAD2(i))
% end




